package torneo;

public class SalbuespenPertsonalizatua extends Exception {

    public SalbuespenPertsonalizatua(String e) {
    }
}
